﻿using dao;
using entity;
using exception;
using System;
using System.Collections.Generic;

namespace main
{
    public class MainModule
    {
        static void Main()
        {
            IVirtualArtGallery service = new VirtualArtGalleryRepository();

            try
            {
                Console.WriteLine("Virtual Art Gallery");
                Console.WriteLine("1. Add Artwork");
                Console.WriteLine("2. Search Artwork");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Write("Enter Title: ");
                    string title = Console.ReadLine();

                    Console.Write("Enter Description: ");
                    string desc = Console.ReadLine();

                    Console.Write("Enter Creation Date (yyyy-MM-dd): ");
                    DateTime creationDate = DateTime.Parse(Console.ReadLine());

                    Console.Write("Enter Medium (e.g., Oil, Acrylic): ");
                    string medium = Console.ReadLine();

                    Console.Write("Enter Image URL: ");
                    string imageUrl = Console.ReadLine();

                    Console.Write("Enter Artist ID: ");
                    int artistId = int.Parse(Console.ReadLine());

                    Artwork art = new Artwork(0, title, desc, creationDate, medium, imageUrl, artistId);
                    bool added = service.AddArtwork(art);

                    Console.WriteLine(added ? "Artwork added successfully." : "Failed to add artwork.");
                }
                else if (choice == 2)
                {
                    Console.Write("Enter keyword to search in title: ");
                    string keyword = Console.ReadLine();

                    List<Artwork> results = service.SearchArtworks(keyword);
                    if (results.Count == 0)
                    {
                        Console.WriteLine("No artworks found.");
                    }
                    else
                    {
                        Console.WriteLine("Matching Artworks:");
                        foreach (Artwork a in results)
                        {
                            Console.WriteLine($"ID: {a.ArtworkID}, Title: {a.Title}, Medium: {a.Medium}, Created: {a.CreationDate.ToShortDateString()}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
            catch (ArtworkNotFoundException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected error: " + e.Message);
            }
        }
    }
}
