﻿using System;

namespace exception
{
    public class ArtworkNotFoundException : Exception
    {
        public ArtworkNotFoundException(string message) : base(message) { }
    }
}
