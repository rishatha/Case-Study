﻿using entity;
using exception;
using util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace dao
{
    public class VirtualArtGalleryRepository : IVirtualArtGallery
    {
        private SqlConnection connection;

        public VirtualArtGalleryRepository()
        {
            connection = DBConnUtil.GetConnection();
        }

        public bool AddArtwork(Artwork artwork)
        {
            string query = "INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL, ArtistID) " +
                           "VALUES (@Title, @Description, @CreationDate, @Medium, @ImageURL, @ArtistID)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@Title", artwork.Title);
            cmd.Parameters.AddWithValue("@Description", artwork.Description);
            cmd.Parameters.AddWithValue("@CreationDate", artwork.CreationDate);
            cmd.Parameters.AddWithValue("@Medium", artwork.Medium);
            cmd.Parameters.AddWithValue("@ImageURL", artwork.ImageURL);
            cmd.Parameters.AddWithValue("@ArtistID", artwork.ArtistID);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool UpdateArtwork(Artwork artwork)
        {
            string query = "UPDATE Artwork SET Title=@Title, Description=@Description, Medium=@Medium WHERE ArtworkID=@ArtworkID";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@Title", artwork.Title);
            cmd.Parameters.AddWithValue("@Description", artwork.Description);
            cmd.Parameters.AddWithValue("@Medium", artwork.Medium);
            cmd.Parameters.AddWithValue("@ArtworkID", artwork.ArtworkID);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool RemoveArtwork(int artworkId)
        {
            string query = "DELETE FROM Artwork WHERE ArtworkID=@id";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@id", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public Artwork GetArtworkById(int artworkId)
        {
            string query = "SELECT * FROM Artwork WHERE ArtworkID=@id";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@id", artworkId);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Artwork art = new Artwork();
                art.ArtworkID = (int)reader["ArtworkID"];
                art.Title = reader["Title"].ToString();
                art.Description = reader["Description"].ToString();
                art.CreationDate = (DateTime)reader["CreationDate"];
                art.Medium = reader["Medium"].ToString();
                art.ImageURL = reader["ImageURL"].ToString();
                art.ArtistID = (int)reader["ArtistID"];
                reader.Close();
                return art;
            }
            reader.Close();
            throw new ArtworkNotFoundException("Artwork ID not found!");
        }

        public List<Artwork> SearchArtworks(string keyword)
        {
            List<Artwork> list = new List<Artwork>();
            string query = "SELECT * FROM Artwork WHERE Title LIKE @keyword OR Description LIKE @keyword";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Artwork art = new Artwork();
                art.ArtworkID = (int)reader["ArtworkID"];
                art.Title = reader["Title"].ToString();
                art.Description = reader["Description"].ToString();
                art.CreationDate = (DateTime)reader["CreationDate"];
                art.Medium = reader["Medium"].ToString();
                art.ImageURL = reader["ImageURL"].ToString();
                art.ArtistID = (int)reader["ArtistID"];
                list.Add(art);
            }
            reader.Close();
            return list;
        }

        public bool AddArtworkToFavorite(int userId, int artworkId)
        {
            string query = "INSERT INTO User_Favorite_Artwork (UserID, ArtworkID) VALUES (@u, @a)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@u", userId);
            cmd.Parameters.AddWithValue("@a", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool RemoveArtworkFromFavorite(int userId, int artworkId)
        {
            string query = "DELETE FROM User_Favorite_Artwork WHERE UserID=@u AND ArtworkID=@a";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@u", userId);
            cmd.Parameters.AddWithValue("@a", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public List<Artwork> GetUserFavoriteArtworks(int userId)
        {
            List<Artwork> favorites = new List<Artwork>();
            string query = "SELECT a.* FROM Artwork a " +
                           "JOIN User_Favorite_Artwork ufa ON a.ArtworkID = ufa.ArtworkID " +
                           "WHERE ufa.UserID = @uid";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@uid", userId);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Artwork art = new Artwork();
                art.ArtworkID = (int)reader["ArtworkID"];
                art.Title = reader["Title"].ToString();
                art.Description = reader["Description"].ToString();
                art.CreationDate = (DateTime)reader["CreationDate"];
                art.Medium = reader["Medium"].ToString();
                art.ImageURL = reader["ImageURL"].ToString();
                art.ArtistID = (int)reader["ArtistID"];
                favorites.Add(art);
            }
            reader.Close();
            return favorites;
        }
    }
}