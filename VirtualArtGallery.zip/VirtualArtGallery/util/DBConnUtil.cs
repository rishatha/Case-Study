﻿using System.Data.SqlClient;

namespace util
{
    public static class DBConnUtil
    {
        public static SqlConnection GetConnection()
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=VirtualArtGalleryDB;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            return conn;
        }
    }
}