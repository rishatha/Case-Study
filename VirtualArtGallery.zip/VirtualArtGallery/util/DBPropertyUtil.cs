﻿using System.Configuration;

namespace util
{
    public static class DBPropertyUtil
    {
        public static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["VirtualArtGalleryDB"].ConnectionString;
        }
    }
}
