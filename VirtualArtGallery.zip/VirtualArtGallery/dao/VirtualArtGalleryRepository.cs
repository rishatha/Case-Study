﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using entity;
using util;
using exception;

namespace dao
{
    public class VirtualArtGalleryRepository : IVirtualArtGallery
    {
        SqlConnection conn;

        public VirtualArtGalleryRepository()
        {
            conn = DBConnUtil.GetConnection();
        }

        public bool AddArtwork(Artwork artwork)
        {
            string sql = "INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL, ArtistID) VALUES (@title, @desc, @date, @medium, @url, @artistId)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@title", artwork.Title);
            cmd.Parameters.AddWithValue("@desc", artwork.Description);
            cmd.Parameters.AddWithValue("@date", artwork.CreationDate);
            cmd.Parameters.AddWithValue("@medium", artwork.Medium);
            cmd.Parameters.AddWithValue("@url", artwork.ImageURL);
            cmd.Parameters.AddWithValue("@artistId", artwork.ArtistID);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool UpdateArtwork(Artwork artwork)
        {
            string sql = "UPDATE Artwork SET Title=@title, Description=@desc, CreationDate=@date, Medium=@medium, ImageURL=@url, ArtistID=@artistId WHERE ArtworkID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@title", artwork.Title);
            cmd.Parameters.AddWithValue("@desc", artwork.Description);
            cmd.Parameters.AddWithValue("@date", artwork.CreationDate);
            cmd.Parameters.AddWithValue("@medium", artwork.Medium);
            cmd.Parameters.AddWithValue("@url", artwork.ImageURL);
            cmd.Parameters.AddWithValue("@artistId", artwork.ArtistID);
            cmd.Parameters.AddWithValue("@id", artwork.ArtworkID);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool RemoveArtwork(int artworkId)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Artwork WHERE ArtworkID = @id", conn);
            cmd.Parameters.AddWithValue("@id", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public Artwork GetArtworkById(int artworkId)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Artwork WHERE ArtworkID = @id", conn);
            cmd.Parameters.AddWithValue("@id", artworkId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                Artwork art = new Artwork(
                    (int)reader["ArtworkID"],
                    reader["Title"].ToString(),
                    reader["Description"].ToString(),
                    (DateTime)reader["CreationDate"],
                    reader["Medium"].ToString(),
                    reader["ImageURL"].ToString(),
                    (int)reader["ArtistID"]
                );
                reader.Close();
                return art;
            }
            reader.Close();
            throw new ArtworkNotFoundException("Artwork not found.");
        }

        public List<Artwork> SearchArtworks(string keyword)
        {
            List<Artwork> list = new List<Artwork>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Artwork WHERE Title LIKE @key", conn);
            cmd.Parameters.AddWithValue("@key", "%" + keyword + "%");
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Artwork(
                    (int)reader["ArtworkID"],
                    reader["Title"].ToString(),
                    reader["Description"].ToString(),
                    (DateTime)reader["CreationDate"],
                    reader["Medium"].ToString(),
                    reader["ImageURL"].ToString(),
                    (int)reader["ArtistID"]
                ));
            }
            reader.Close();
            return list;
        }

        public List<Artwork> GetAllArtworks()
        {
            List<Artwork> list = new List<Artwork>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Artwork", conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Artwork(
                    (int)reader["ArtworkID"],
                    reader["Title"].ToString(),
                    reader["Description"].ToString(),
                    (DateTime)reader["CreationDate"],
                    reader["Medium"].ToString(),
                    reader["ImageURL"].ToString(),
                    (int)reader["ArtistID"]
                ));
            }
            reader.Close();
            return list;
        }

        public bool AddArtworkToFavorite(int userId, int artworkId)
        {
            string sql = "INSERT INTO User_Favorite_Artwork (UserID, ArtworkID) VALUES (@userId, @artworkId)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@artworkId", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool RemoveArtworkFromFavorite(int userId, int artworkId)
        {
            string sql = "DELETE FROM User_Favorite_Artwork WHERE UserID = @userId AND ArtworkID = @artworkId";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@artworkId", artworkId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public List<Artwork> GetUserFavoriteArtworks(int userId)
        {
            List<Artwork> list = new List<Artwork>();
            string sql = @"SELECT a.* FROM Artwork a 
                           INNER JOIN User_Favorite_Artwork ufa ON a.ArtworkID = ufa.ArtworkID 
                           WHERE ufa.UserID = @userId";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@userId", userId);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Artwork(
                    (int)reader["ArtworkID"],
                    reader["Title"].ToString(),
                    reader["Description"].ToString(),
                    (DateTime)reader["CreationDate"],
                    reader["Medium"].ToString(),
                    reader["ImageURL"].ToString(),
                    (int)reader["ArtistID"]
                ));
            }
            reader.Close();
            return list;
        }
    }
}
