﻿using dao;
using entity;
using exception;
using System;
using System.Collections.Generic;

namespace main
{
    public class MainModule
    {
        static void Main()
        {
            IVirtualArtGallery service = new VirtualArtGalleryRepository();
            try
            {
                Console.WriteLine("1. Add Artwork\n2. Search Artwork\nEnter choice:");
                int choice = int.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    Artwork art = new Artwork(0, "Mona Lisa", "Famous painting", DateTime.Now, "Oil", "http://img.com/1", 1);
                    bool added = service.AddArtwork(art);
                    Console.WriteLine(added ? "Added successfully" : "Failed to add");
                }
                else if (choice == 2)
                {
                    List<Artwork> results = service.SearchArtworks("Mona");
                    foreach (Artwork a in results)
                        Console.WriteLine(a.ArtworkID + " - " + a.Title);
                }
            }
            catch (ArtworkNotFoundException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected: " + e.Message);
            }
        }
    }
}
