﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using entity;

namespace VirtualArtGallery.Tests
{
    [TestFixture]
    public class VirtualArtGalleryUnitTests
    {
        // --- Artwork Tests ---
        [Test]
        public void Artwork_Constructor_ShouldSetPropertiesCorrectly()
        {
            int id = 1;
            string title = "Starry Night";
            string desc = "Famous painting";
            DateTime date = new DateTime(1889, 6, 1);
            string medium = "Oil";
            string url = "http://starrynight.jpg";
            int artistId = 2;

            Artwork artwork = new Artwork(id, title, desc, date, medium, url, artistId);

            Assert.AreEqual(id, artwork.ArtworkID);
            Assert.AreEqual(title, artwork.Title);
            Assert.AreEqual(desc, artwork.Description);
            Assert.AreEqual(date, artwork.CreationDate);
            Assert.AreEqual(medium, artwork.Medium);
            Assert.AreEqual(url, artwork.ImageURL);
            Assert.AreEqual(artistId, artwork.ArtistID);
        }

        [Test]
        public void Artwork_UpdateProperties_ShouldReflectChanges()
        {
            Artwork artwork = new Artwork(1, "Old Title", "Old Desc", DateTime.Now, "Oil", "url", 2);
            artwork.Title = "New Title";
            artwork.Description = "New Description";

            Assert.AreEqual("New Title", artwork.Title);
            Assert.AreEqual("New Description", artwork.Description);
        }

        [Test]
        public void Artwork_SearchByTitle_ShouldReturnExpectedResults()
        {
            var artworks = new List<Artwork>
            {
                new Artwork(1, "Sunset", "A sunset view", DateTime.Now, "Oil", "url1", 1),
                new Artwork(2, "Sunrise", "A sunrise view", DateTime.Now, "Acrylic", "url2", 2)
            };

            var results = artworks.FindAll(a => a.Title.Contains("Sun"));

            Assert.AreEqual(2, results.Count);
        }

        // --- Gallery Tests ---
        [Test]
        public void Gallery_Constructor_ShouldSetPropertiesCorrectly()
        {
            int id = 1;
            string name = "Modern Gallery";
            string description = "Modern art collection";
            string location = "New York";
            int curatorId = 10;
            string hours = "10:00 AM - 6:00 PM";

            Gallery gallery = new Gallery(id, name, description, location, curatorId, hours);

            Assert.AreEqual(id, gallery.GalleryID);
            Assert.AreEqual(name, gallery.Name);
            Assert.AreEqual(description, gallery.Description);
            Assert.AreEqual(location, gallery.Location);
            Assert.AreEqual(curatorId, gallery.Curator);
            Assert.AreEqual(hours, gallery.OpeningHours);
        }

        [Test]
        public void Gallery_UpdateProperties_ShouldReflectChanges()
        {
            Gallery gallery = new Gallery();
            gallery.Name = "Initial Name";
            gallery.Location = "Initial Location";

            gallery.Name = "Updated Name";
            gallery.Location = "Updated Location";

            Assert.AreEqual("Updated Name", gallery.Name);
            Assert.AreEqual("Updated Location", gallery.Location);
        }

        [Test]
        public void Gallery_SearchByName_ShouldReturnExpectedResults()
        {
            var galleries = new List<Gallery>
            {
                new Gallery(1, "Modern Art", "Desc", "Paris", 1, "9-5"),
                new Gallery(2, "Classic Art", "Desc", "Rome", 2, "10-6")
            };

            var results = galleries.FindAll(g => g.Name.Contains("Art"));

            Assert.AreEqual(2, results.Count);
        }
    }
}
