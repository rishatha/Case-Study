﻿using System;
using System.Collections.Generic;
using dao;
using entity;
using exception;

namespace main
{
    public class MainModule
    {
        static void Main()
        {
            IVirtualArtGallery service = new VirtualArtGalleryRepository();

            while (true)
            {
                Console.WriteLine("\n=== Virtual Art Gallery Menu ===");
                Console.WriteLine("1. Add Artwork");
                Console.WriteLine("2. Update Artwork");
                Console.WriteLine("3. Delete Artwork");
                Console.WriteLine("4. View Artwork by ID");
                Console.WriteLine("5. Search Artworks by Title");
                Console.WriteLine("6. View All Artworks");
                Console.WriteLine("7. Add Artwork to Favorites");
                Console.WriteLine("8. Remove Artwork from Favorites");
                Console.WriteLine("9. View User's Favorite Artworks");
                Console.WriteLine("10. Exit");
                Console.Write("Enter your choice: ");

                int choice = int.Parse(Console.ReadLine());

                try
                {
                    switch (choice)
                    {
                        case 1:
                            Console.Write("Enter Title: ");
                            string title = Console.ReadLine();
                            Console.Write("Enter Description: ");
                            string desc = Console.ReadLine();
                            Console.Write("Enter Creation Date (yyyy-MM-dd): ");
                            DateTime date = DateTime.Parse(Console.ReadLine());
                            Console.Write("Enter Medium: ");
                            string medium = Console.ReadLine();
                            Console.Write("Enter Image URL: ");
                            string img = Console.ReadLine();
                            Console.Write("Enter Artist ID: ");
                            int artistId = int.Parse(Console.ReadLine());

                            Artwork newArt = new Artwork(0, title, desc, date, medium, img, artistId);
                            bool added = service.AddArtwork(newArt);
                            Console.WriteLine(added ? "Artwork added." : "Failed to add artwork.");
                            break;

                        case 2:
                            Console.Write("Enter Artwork ID to update: ");
                            int upId = int.Parse(Console.ReadLine());
                            Console.Write("Enter New Title: ");
                            string newTitle = Console.ReadLine();
                            Console.Write("Enter New Description: ");
                            string newDesc = Console.ReadLine();
                            Console.Write("Enter New Date (yyyy-MM-dd): ");
                            DateTime newDate = DateTime.Parse(Console.ReadLine());
                            Console.Write("Enter New Medium: ");
                            string newMedium = Console.ReadLine();
                            Console.Write("Enter New Image URL: ");
                            string newUrl = Console.ReadLine();
                            Console.Write("Enter Artist ID: ");
                            int newArtistId = int.Parse(Console.ReadLine());

                            Artwork updateArt = new Artwork(upId, newTitle, newDesc, newDate, newMedium, newUrl, newArtistId);
                            bool updated = service.UpdateArtwork(updateArt);
                            Console.WriteLine(updated ? "Artwork updated." : "Update failed.");
                            break;

                        case 3:
                            Console.Write("Enter Artwork ID to delete: ");
                            int delId = int.Parse(Console.ReadLine());
                            bool deleted = service.RemoveArtwork(delId);
                            Console.WriteLine(deleted ? "Artwork deleted." : "Delete failed.");
                            break;

                        case 4:
                            Console.Write("Enter Artwork ID: ");
                            int aid = int.Parse(Console.ReadLine());
                            Artwork art = service.GetArtworkById(aid);
                            Console.WriteLine(art);
                            break;

                        case 5:
                            Console.Write("Enter keyword to search: ");
                            string keyword = Console.ReadLine();
                            var results = service.SearchArtworks(keyword);
                            foreach (var a in results)
                                Console.WriteLine(a);
                            break;

                        case 6:
                            var allArt = service.GetAllArtworks();
                            foreach (var a in allArt)
                                Console.WriteLine(a);
                            break;

                        case 7:
                            Console.Write("Enter User ID: ");
                            int uid1 = int.Parse(Console.ReadLine());
                            Console.Write("Enter Artwork ID: ");
                            int favAid = int.Parse(Console.ReadLine());
                            bool favAdded = service.AddArtworkToFavorite(uid1, favAid);
                            Console.WriteLine(favAdded ? "Added to favorites." : "Failed.");
                            break;

                        case 8:
                            Console.Write("Enter User ID: ");
                            int uid2 = int.Parse(Console.ReadLine());
                            Console.Write("Enter Artwork ID: ");
                            int rmAid = int.Parse(Console.ReadLine());
                            bool favRemoved = service.RemoveArtworkFromFavorite(uid2, rmAid);
                            Console.WriteLine(favRemoved ? "Removed from favorites." : "Failed.");
                            break;

                        case 9:
                            Console.Write("Enter User ID: ");
                            int uid3 = int.Parse(Console.ReadLine());
                            var favorites = service.GetUserFavoriteArtworks(uid3);
                            foreach (var fav in favorites)
                                Console.WriteLine(fav);
                            break;

                        case 10:
                            Console.WriteLine("Exiting...");
                            return;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (ArtworkNotFoundException ex)
                {
                    Console.WriteLine("Artwork Error: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected error: " + ex.Message);
                }
            }
        }
    }
}
