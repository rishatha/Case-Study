﻿using System;

namespace entity
{
    public class Artwork
    {
        public int ArtworkID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreationDate { get; set; }
        public string Medium { get; set; }
        public string ImageURL { get; set; }
        public int ArtistID { get; set; }

        public Artwork() { }

        public Artwork(int id, string title, string desc, DateTime date, string medium, string url, int artistId)
        {
            ArtworkID = id;
            Title = title;
            Description = desc;
            CreationDate = date;
            Medium = medium;
            ImageURL = url;
            ArtistID = artistId;
        }
    }
    public class Artist
    {
        public int ArtistID { get; set; }
        public string Name { get; set; }
        public string Biography { get; set; }
        public DateTime BirthDate { get; set; }
        public string Nationality { get; set; }
        public string Website { get; set; }
        public string ContactInformation { get; set; }

        public Artist() { }

        public Artist(int id, string name, string bio, DateTime birthDate, string nationality, string website, string contact)
        {
            ArtistID = id;
            Name = name;
            Biography = bio;
            BirthDate = birthDate;
            Nationality = nationality;
            Website = website;
            ContactInformation = contact;
        }
    }
}